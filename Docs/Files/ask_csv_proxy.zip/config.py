import os
BASE_URL =  os.getenv("API_BASE_URL", "")
BASE_AUTH_ENDPOINT = ""
AUTH_PATH = "oauth2/token"
BEDROCK_PROXY_PATH = "proxy/aws/bedrock"
BEDROCK_CONV_PATH = "models/bedrock"
TEXTRACT_PROXY_PATH = "proxy/aws/textract"
TEXTRACT_CONV_PATH = "models/textract"
JOBS_PATH = "jobs"

URL_ENCODED = "application/x-www-form-urlencoded"
JSON = "application/json"

CLIENT_CREDS = "client_credentials"

TOTAL_WAIT_TIME = 120
INTERVAL_TIME = 10
